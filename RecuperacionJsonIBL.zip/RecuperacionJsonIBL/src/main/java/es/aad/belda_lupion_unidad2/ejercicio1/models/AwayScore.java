package es.aad.belda_lupion_unidad2.ejercicio1.models;

/**
 * AwayScore class
 * will save information about the AwayScore
 * @author Nacho
 */
public class AwayScore
{
    /**
     * Attribute home_score
     * will save the information about the Score that does the home team
     */
    int away_score;

    /**
     * Empty constructor
     */
    public AwayScore()
    {
    }

    /**
     * Beans
     */
    public int getAway_score() {
        return away_score;
    }

    public void setAway_score(int away_score) {
        this.away_score = away_score;
    }

    /**
     * toString
     */
    @Override
    public String toString()
    {
        return "AwayScore{" +
                "away_score=" + away_score +
                '}';
    }
}
