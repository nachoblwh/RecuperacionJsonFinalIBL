package es.aad.belda_lupion_unidad2.ejercicio1.models;

/**
 * HomeScore Class
 * This class will save the information about the Score that does the home team
 */
public class HomeScore
{
    /**
     * Attribute home_score
     * will save the information about the Score that does the home team
     */
    int home_score;

    /**
     * Empty constructor
     */
    public HomeScore()
    {
    }

    /**
     * Beans
     * @return
     */
    public int getHome_score() {
        return home_score;
    }

    public void setHome_score(int home_score) {
        this.home_score = home_score;
    }

    /**
     * toString
     * @return
     */
    @Override
    public String toString() {
        return "HomeScore{" +
                "home_score=" + home_score +
                '}';
    }
}
